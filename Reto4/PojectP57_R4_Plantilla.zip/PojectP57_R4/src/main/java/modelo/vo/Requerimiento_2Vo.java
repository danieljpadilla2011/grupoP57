package modelo.vo;

public class Requerimiento_2Vo {
    // Su código
}
