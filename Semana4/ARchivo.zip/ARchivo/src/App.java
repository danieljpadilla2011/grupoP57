import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        // Lectura de Datos de Un Archivo
        try {
            File f = new File("nombres.txt");
            Scanner sc = new Scanner(f);
            while (sc.hasNextLine()) {
                String linea = sc.nextLine();
                System.out.println(linea);
            }
            sc.close();
            // f.delete();

        } catch (Exception e) {
            System.out.println("Falló la lectura del archivo " + e.getMessage());
            e.getStackTrace();
        }

        // Escritura de Datos sobre un archivo

        String datos[] = { "Manzana", "Pera", "Uvas", "Cocos", "Bananos" };
        FileWriter archivo = new FileWriter("frutas.txt");
        for (String i : datos) {
            archivo.write(i + "\n");
        }
        archivo.close();

        // Añadir datos a un archivo
        String datos2[] = { "Limon", "Lulo", "Mango" };
        FileWriter archivo2 = new FileWriter("frutas.txt", true);
        for (String j : datos2) {
            archivo2.write(j + "\n");
        }
        archivo2.close();

    }
}
