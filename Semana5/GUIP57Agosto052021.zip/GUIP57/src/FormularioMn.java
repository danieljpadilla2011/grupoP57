import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class FormularioMn extends JFrame implements ActionListener {
    private JTextField cmpColor;
    private JMenuBar mb;
    private JMenu menu1, menu2;
    private JMenuItem mi1, mi2, mi3;

    public FormularioMn() {
        setLayout(null);
        mb = new JMenuBar();
        setJMenuBar(mb);
        menu1 = new JMenu("Opciones");
        mb.add(menu1);
        menu2 = new JMenu("Ayuda");
        mb.add(menu2);

        mi1 = new JMenuItem("Rojo");
        menu1.add(mi1);
        mi1.addActionListener(this);

        mi2 = new JMenuItem("Verde");
        menu1.add(mi2);
        mi2.addActionListener(this);

        mi3 = new JMenuItem("Azul");
        menu1.add(mi3);
        mi3.addActionListener(this);

        cmpColor = new JTextField();
        cmpColor.setBounds(100, 100, 200, 100);
        add(cmpColor);

        //
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == mi1) {
            cmpColor.setBackground(new Color(255, 0, 0));
        }

        if (e.getSource() == mi2) {
            cmpColor.setBackground(new Color(0, 255, 0));
        }

        if (e.getSource() == mi3) {
            cmpColor.setBackground(new Color(0, 0, 255));
        }

    }

}
