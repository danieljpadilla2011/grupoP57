import javax.swing.*;
import java.awt.event.*;

public class FormularioCB extends JFrame implements ItemListener {
    private JComboBox<String> cmbColores;

    public FormularioCB() {
        setLayout(null);
        cmbColores = new JComboBox<String>();
        cmbColores.setBounds(10, 10, 80, 20);
        add(cmbColores);
        cmbColores.addItem("verde");
        cmbColores.addItem("azul");
        cmbColores.addItem("Amarillo");
        cmbColores.addItem("Naranja");
        cmbColores.addItem("Gris");
        cmbColores.addItemListener(this);
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource() == cmbColores) {
            String cad = (String) cmbColores.getSelectedItem();
            // setTitle(cad);
            JOptionPane.showMessageDialog(null, cad, "Color Seleccionado", JOptionPane.WARNING_MESSAGE);
        }
    }

}
