import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.event.*;

public class FormularioTextField extends JFrame implements ActionListener {
    private JTextField textField1;
    private JLabel label1;
    private JButton boton1;

    public FormularioTextField() {
        setLayout(null);
        label1 = new JLabel("Usuario:");
        label1.setBounds(10, 10, 100, 30);
        add(label1);
        textField1 = new JTextField();
        textField1.setBounds(120, 10, 150, 20);
        add(textField1);
        boton1 = new JButton("Aceptar");
        boton1.setBounds(10, 80, 100, 30);
        add(boton1);
        boton1.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton1) {
            String cad = textField1.getText();
            setTitle(cad);
        }
    }

    public static void main(String[] args) {
        FormularioTextField formulario = new FormularioTextField();
        formulario.setBounds(0, 0, 350, 200);
        formulario.setVisible(true);
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
