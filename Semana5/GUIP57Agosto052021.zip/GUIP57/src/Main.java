import javax.swing.JFrame;

public class Main {
    public static void main(String[] args) {
        FormularioChB formulario = new FormularioChB();
        formulario.setBounds(200, 200, 400, 400);
        formulario.setVisible(true);
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
