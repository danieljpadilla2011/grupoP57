import javax.swing.*;

public class FormularioTA extends JFrame {
    private JTextField cmpNombre;
    private JTextArea txaInfo;
    private JScrollPane scpInfo;

    public FormularioTA() {
        setLayout(null);
        cmpNombre = new JTextField();
        cmpNombre.setBounds(10, 10, 200, 30);
        add(cmpNombre);
        txaInfo = new JTextArea();
        // txaInfo.setBounds(10, 60, 400, 300);
        // add(txaInfo);
        scpInfo = new JScrollPane(txaInfo);
        scpInfo.setBounds(10, 60, 400, 300);
        add(scpInfo);

    }

}
