import javax.swing.*;

public class JFrameBasico {
    public static void main(String[] args) {
        JFrame frameBasico = new JFrame();
        frameBasico.setBounds(10, 20, 300, 200);
        frameBasico.setVisible(true);
        frameBasico.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
