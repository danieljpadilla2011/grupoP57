import javax.swing.*;

public class Formulario extends JFrame {
    private JLabel label1, label2;

    public Formulario() {
        setLayout(null);
        label1 = new JLabel("Mision TIC 2022");
        label1.setBounds(10, 20, 300, 30);
        add(label1);
        label2 = new JLabel("Programación Java");
        label2.setBounds(10, 100, 200, 30);
        add(label2);
    }

    public static void main(String[] args) {
        Formulario formulario1 = new Formulario();
        formulario1.setBounds(0, 0, 400, 300);
        formulario1.setResizable(false);
        formulario1.setVisible(true);
        formulario1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
